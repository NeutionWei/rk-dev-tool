1. Unpack
     Copy the officially released firmware to the current directory, 
	 rename it to update.img, and execute unpack.sh
     After unpacking, the generated files are in the output directory.

2. Repack
     Keep the current directory structure, file name, etc. unchanged, 
	 and replace the file with the same name under output/ with the customer's own file
     Execute pack.sh, after execution, generate new_update.img, which is the packaged firmware
         The rootfs file name must be rootfs.img
         parameter.txt file name must be parameter.txt

Note:
    During the package process, if the rootfs partition is not the last partition, the program will automatically modify the size of the rootfs partition in parameter.txt according to the size of the rootfs file.
    If the user changes parameter.txt by himself, please pay attention to the whole contracting process.

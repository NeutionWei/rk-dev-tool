# 截屏工具

https://blog.csdn.net/aiwangtingyun/article/details/79558152
读取设备文件 /dev/fb 的图像信息，保存为 bmp 图片。可用于 buildroot 截屏。

## 编译

gcc -o screen screen.c

## 执行

./screen screen.bmp

